# WiFi Bruteforcer - Fsecurify
**WARNING:** This project is still under development and by installing the app may desconfigure the Wi-Fi settings of your Android OS, a system restore may be necessary to fix it.

Android application to brute force WiFi passwords without requiring a rooted device.

![Alt text](1280.jpg?raw=true "Fsecurify")

DownloadLink:
http://fsecurify.com/wifi-bruteforcer-android-app-to-crack-wifi-passwords/
